package com.common.base.rxjava2;

/**
 * 类描述：请求服务loading关闭监听
 */

public interface ProgressCancelListener {
    void onCancelProgress();
}
