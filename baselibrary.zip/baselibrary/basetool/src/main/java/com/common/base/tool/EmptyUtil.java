package com.common.base.tool;

/**
 * created by 李云 on 2019/1/3
 * 本类的作用:
 */
public class EmptyUtil {
    public static boolean isObjEmpty(Object obj) {
        return obj == null;
    }
}
