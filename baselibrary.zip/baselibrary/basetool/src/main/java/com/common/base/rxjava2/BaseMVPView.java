package com.common.base.rxjava2;

/**
 * @description: base
 */

public interface BaseMVPView<T> {
}
