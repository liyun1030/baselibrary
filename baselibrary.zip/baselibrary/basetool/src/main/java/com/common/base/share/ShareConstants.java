package com.common.base.share;


public class ShareConstants {
    // 微信APP_ID：为你的应用从官方网站申请到的合法appId
    public static final String WX_APP_ID = "wxdd44c96a85693969";
    public static final String WX_SECRET = "2488abf8baaca7f5a7a9d10701eee281";

    public static final String WB_APP_ID = "508896767";
    public static final String WB_REDIRECT_URL = "http://sns.whalecloud.com/sina2/callback";

    public static final String QQ_APP_ID = "1104913493";

    public static final String APP_LAUNCH = "http://cdn.curefun.com/ic_launcher.png";

    public static final String TYPE = "type";
    public static final String TO = "to";

    public static final int TYPE_IMAGE = 3;//图片
    public static final int TO_FRIEND = 1;//朋友
    public static final int PUBLISH_QZONE = 3;
}
