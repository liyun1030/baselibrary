package com.common.base.view.emoji;

/**
 * created by 李云 on 2019/5/5
 * 本类的作用:
 */
public class EmoBean {
    String ch;
    String suffix;
    String fileName;

    public String getCh() {
        return ch;
    }

    public void setCh(String ch) {
        this.ch = ch;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
