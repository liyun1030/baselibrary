package com.common.base.bean;

import java.io.Serializable;

public class ImageItem implements Serializable {
    public String path;

}
