package com.common.base.rxjava2;

/**
 * @description: base presenter
 */
public interface BaseMVPPresenter {

}
